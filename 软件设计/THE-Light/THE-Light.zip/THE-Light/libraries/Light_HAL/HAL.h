
/*******************************************************************************
  * Name    :HAL.h
  * Author  : XiaoYI
  * Function:****
  * Version :V1.0.0
  * Data    :2025.4.9
*******************************************************************************/
#ifndef _HAL_H__
#define _HAL_H__

/*-------------include file---------------------------*/
#include  <Arduino.h>

//This is the hardware abstraction layer，Provide users with underlying hardware interfaces

#include <RTE.h>
/*-------------variable statement---------------------*/
#define False 0
#define True 1
//Anti shake time threshold (adjusted according to actual switch)
#define DEBOUNCE_TIME 400 
// define Intereupt IN0~D2,IN1~D3
#define Extern_PIN 3
// define keystroke NUM
#define HAL_Study_room 4
#define HAL_Bedr_room 7

/* 3 5 6 9 10 11 PWM pin，5 6 940hz，other 450hz*/
//study room
#define Light_Pin1Y 5
#define Light_Pin1W 6
//bedroom
#define Light_Pin2Y 10
#define Light_Pin2W 11

// Init Light Lux
#define HAL_Light_OFF 0

// interrupt Flag
uint8_t interrupt_Flag = False;

uint8_t HAL_Light_HIgh = 100;
uint8_t HAL_Light_CT_NEUTRAL = 100;

//HAL Light State


//define Extern Interrupt State to change SYS State
volatile uint32_t last_interrupt_time = 0; // 
volatile uint8_t SYS_Extern_state = False; // 
volatile uint8_t SYS_Extern_count = 0;

typedef void (*LightActionHandler) (uint8_t W_D_C,uint8_t Y_D_C);
//HAL Light choose
typedef enum
{
  HAL_Light_Study,
  HAL_LIght_bedroom

}HalLightSwitch;

// Event
typedef enum
{
  Normal_State=0,
  ENERGY_State,
  Auto_State
}HalModeChange;

//Hal_Light_State_Choose_Num
typedef struct
{
  uint8_t HAL_Light_Study_State;
  uint8_t HAL_LIght_bedroom_State;
}Hal_Light_State_Choose;
Hal_Light_State_Choose Hal_Light_State_Choose_Structrue = {0,0};
//DRV GPIO define
typedef struct
{
  /*  */
 LightActionHandler Hal_Light_study;
 LightActionHandler Hal_LIght_bedroom;
 /*  */
 HalLightSwitch HAL_Light_Switch;
 /* */
 HalModeChange Hal_Mode_Change;

}HAL_Light_Control;


/*------------------function---define-----------------------*/
/*
extern Init interface
*/
extern void Light_Init(void); 
extern void Uart_Init(uint8_t baud);
extern void keystroke_Init(void);
extern void  Extern_Interrupt_Init(void);
/*
extern Need interface
*/
extern void Extern_Normal_HAL_Light_Switch_Run(void);
extern void Extern_ENERGY_HAL_Light_Switch_Run(void);
extern void Light_ExecuteAction(LightActionHandler Action,uint8_t W_D_C,uint8_t Y_D_C);


/*------------------function--------------------------*/

//IO Init
void Light_Init() 
{
     pinMode(Light_Pin1Y,OUTPUT);
     pinMode(Light_Pin1W,OUTPUT);
     pinMode(Light_Pin2Y,OUTPUT);
     pinMode(Light_Pin2W,OUTPUT);
}
void  keystroke_Init()
{
  pinMode(HAL_Study_room,INPUT_PULLUP);
  pinMode(HAL_Bedr_room,INPUT_PULLUP);

}
void Uart_Init(uint8_t baud)
{
  Serial.begin(baud);// TX 1 RX 0
}

void  Extern_Interrupt_Init()
{
   pinMode(Extern_PIN, INPUT_PULLUP);
    EICRA |= (1 << ISC11);    // Falling 
    EIMSK |= (1 << INT1);     // start INT1 Interrupt
    EIFR  |= (1 << INTF1);
}

// Light duty cycle 
void Light1_Duty_Cycle(uint8_t W_D_C,uint8_t Y_D_C)
{
  analogWrite(Light_Pin1W, W_D_C);
  analogWrite(Light_Pin1Y, Y_D_C);
}

void Light2_Duty_Cycle(uint8_t W_D_C,uint8_t Y_D_C)
{
   analogWrite(Light_Pin2W, W_D_C);
   analogWrite(Light_Pin2Y, Y_D_C);
}
//External call interface function
void Light_ExecuteAction(LightActionHandler Action,uint8_t W_D_C,uint8_t Y_D_C)
{
  if(Action!=NULL)
  {
    Action( W_D_C, Y_D_C);
  }
}
//Init struct
HAL_Light_Control HAL_Light_Control_Structure =
{
  .Hal_Light_study = Light1_Duty_Cycle,
  .Hal_LIght_bedroom = Light2_Duty_Cycle,
  .HAL_Light_Switch = HAL_LIght_bedroom,
  .Hal_Mode_Change = Normal_State

};
// HAL LIGHt Swicth Run 
/*Normal*/
 void Normal_HAL_Light_Switch_Run(HAL_Light_Control* Hal_Light_choose,Hal_Light_State_Choose* Hal_Light_Statechoose)
{
  if(!Hal_Light_choose)return;
  if(digitalRead(HAL_Study_room)==LOW)
  {
      Hal_Light_choose->HAL_Light_Switch=HAL_Light_Study;
      Hal_Light_Statechoose->HAL_Light_Study_State = True;
  }
  else
  {
    Hal_Light_Statechoose->HAL_Light_Study_State = False;
  }
   if(digitalRead(HAL_Bedr_room)==LOW)
  {
    Hal_Light_choose->HAL_Light_Switch=HAL_LIght_bedroom;
    Hal_Light_Statechoose->HAL_LIght_bedroom_State = True;
  }
   else
  {
    Hal_Light_Statechoose->HAL_LIght_bedroom_State = False;
  }

}

static void Extern_Normal_HAL_Light_Switch_Run()
{
  Normal_HAL_Light_Switch_Run(&HAL_Light_Control_Structure,&Hal_Light_State_Choose_Structrue);
}
/*ENERGY*/
 void ENERGY_HAL_Light_Switch_Run(HAL_Light_Control* Hal_Light_choose,Hal_Light_State_Choose* Hal_Light_Statechoose)
{
  if(!Hal_Light_choose)return;
  if(digitalRead(HAL_Study_room)==LOW)
  {
      Hal_Light_choose->HAL_Light_Switch=HAL_Light_Study;
      Hal_Light_Statechoose->HAL_Light_Study_State = True;
  }
  else
  {
    Hal_Light_Statechoose->HAL_Light_Study_State = False;
  }
   if(digitalRead(HAL_Bedr_room)==LOW)
  {
    Hal_Light_choose->HAL_Light_Switch=HAL_LIght_bedroom;
    Hal_Light_Statechoose->HAL_LIght_bedroom_State = True;
  }
   else
  {
    Hal_Light_Statechoose->HAL_LIght_bedroom_State = False;
  }
}
static void Extern_ENERGY_HAL_Light_Switch_Run()
{
  ENERGY_HAL_Light_Switch_Run(&HAL_Light_Control_Structure,&Hal_Light_State_Choose_Structrue);
}


// INT1 Interrupt service
ISR(INT1_vect) 
{  
  //Extern_state= True;
  uint32_t now = millis();
  if(now - last_interrupt_time < DEBOUNCE_TIME) return;
  last_interrupt_time = now;
  interrupt_Flag = True; 
  switch(SYS_Extern_count)
   {
    case 0: HAL_Light_Control_Structure.Hal_Mode_Change = Normal_State;break;
    case 1: HAL_Light_Control_Structure.Hal_Mode_Change = ENERGY_State;break;
    case 2: HAL_Light_Control_Structure.Hal_Mode_Change = Auto_State;break;
   }
   SYS_Extern_count=(SYS_Extern_count+1)%3;//0~2
   
}

#endif
