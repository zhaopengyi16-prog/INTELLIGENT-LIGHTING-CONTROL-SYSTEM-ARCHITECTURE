/*******************************************************************************
  * Name    :RTE.h
  * Author  : XiaoYI
  * Function:****
  * Version :V1.0.0
  * Data    :2025.4.9
*******************************************************************************/
//This layer is in the middle and is mainly used to process data and decouple software and hardware
#ifndef _RTE_H__
#define _RTE_H__

/*-------------include file---------------------------*/
#include  <Arduino.h>

#include <HAL.h>
#include <APP.h>
/*-------------variable statement---------------------*/


/*
    Light+local name
 */
typedef enum
{
    Light_study,       // study room
    LIght_bedroom      //bedroom

}LightSwitch;


/*
This is the central control command selection
 */


typedef enum
{
    SYS_NORMAL,        //Normal mode
    SYS_AUTO_PROFILE,  //profile mode
    SYS_ENERGY_SAVING  //Energy saving mode

} SystemMode;
/*
Is anyone judging
 */
typedef enum
{
  None_State,
  Some_State
}AnyoneJudg;

/*
This is the selection of lighting status 
 */
typedef enum 
{
    LIGHT_OFF,
    LIGHT_ON,
    LIGHT_AUTO

} LightState;

/*
This is the color temperature selection for lighting
 */
 typedef enum
{
    CT_COLD,
    CT_WARM,
    CT_NEUTRAL,       
    CT_AUTO
} ColorTemperatureMode;
/*
This is a state triggered event
*//*
typedef enum
{
    Event_Normal,
    Event_ENERGY_SAVING,
    Event_AUTO_PROFILE,

    Event_CT_COLD,
    Event_CT_WARM,
    Event_CT_NEUTRAL,
    Event_CT_AUTO,

}EventChange;
*/
/*********   struct    *********/

/*
This is the system architecture
 */
typedef struct
 {
    SystemMode Sys_mode;
    AnyoneJudg Anyone_Judg;
    LightState Light_state;
    ColorTemperatureMode CT_mode; 
    LightSwitch Light_Switch;
    //EventChange Event_Change;
    uint8_t Brightness;   
   // uint16_t Auto_off_timer;  
} Light_System;
Light_System LightSystem;




//app use
extern void Task_process_lighting_state(Light_System* sys);

//down extern use
extern void Task_Init(void);
extern void Task_Event_Mode_Check(void);
extern void Task_switch_Begin(void);

//self
/*
all function 
*/
void set_system_mode(Light_System* sys, SystemMode new_mode);
void Light_system_Init(Light_System* sys);
static void Handle_Light_Control(Light_System* sys);
void Handle_normal_mode(Light_System* sys);
void Handle_auto_profile(Light_System* sys);
void Handle_energy_saving(Light_System* sys);
void Light_system_Init(Light_System* sys);

/*------------------function--------------------------*/
// State change
void set_system_mode(Light_System* sys, SystemMode new_mode) {
    if (!sys) return;
     
    sys->Sys_mode = new_mode;  
    // Initialize after switching
    switch(new_mode) {
        case SYS_NORMAL:


            break;
        case SYS_ENERGY_SAVING:

       

            break;
         case SYS_AUTO_PROFILE:

     
            break;
       
    }
}
//Light_handle
static void Handle_Light_Control(Light_System* sys)
{
 if (!sys) return; 
 switch(sys->Light_Switch)
 {
    case Light_study:
        if(sys->Light_state==LIGHT_ON)
        {
            Light_ExecuteAction(HAL_Light_Control_Structure.Hal_Light_study,HAL_Light_HIgh,HAL_Light_HIgh);
        }
        if(sys->Light_state==LIGHT_OFF)
        {
            Light_ExecuteAction(HAL_Light_Control_Structure.Hal_Light_study,HAL_Light_OFF,HAL_Light_OFF);
        }
        if(sys->Light_state==LIGHT_AUTO)
        {
          
        }
        break;
    case LIght_bedroom:
        if(sys->Light_state==LIGHT_ON)
        {
            Light_ExecuteAction(HAL_Light_Control_Structure.Hal_LIght_bedroom,HAL_Light_HIgh,HAL_Light_HIgh);
        }
        if(sys->Light_state==LIGHT_OFF)
        {
             Light_ExecuteAction(HAL_Light_Control_Structure.Hal_LIght_bedroom,HAL_Light_OFF,HAL_Light_OFF);
        }
        if(sys->Light_state==LIGHT_AUTO)
        {
            
        }
        break;
 }
 
  

}
//SYS handle mode
 void Handle_normal_mode(Light_System* sys)
{
  if (!sys) return;
   Extern_Normal_HAL_Light_Switch_Run();
   switch(HAL_Light_Control_Structure.HAL_Light_Switch)
   {
    case HAL_Light_Study:
        sys->Light_Switch = Light_study;
        if(Hal_Light_State_Choose_Structrue.HAL_Light_Study_State==True)
        {
            sys->Light_state = LIGHT_ON;
        }
        else{ sys->Light_state = LIGHT_OFF;}
        Handle_Light_Control(sys);
    break;
    case HAL_LIght_bedroom:
        sys->Light_Switch = LIght_bedroom;
        if(Hal_Light_State_Choose_Structrue.HAL_LIght_bedroom_State==True)
        {
            sys->Light_state = LIGHT_ON;
        }
        else{ sys->Light_state = LIGHT_OFF;}
        Handle_Light_Control(sys);
    break;

   }
   
  
}

 void Handle_auto_profile(Light_System* sys)
{
  if (!sys) return;
     sys->Light_Switch = Light_study;
      sys->Light_state = LIGHT_ON;
       Handle_Light_Control(sys);
        delay(500);
         sys->Light_Switch = Light_study;
      sys->Light_state = LIGHT_OFF;
       Handle_Light_Control(sys);
       delay(500);


}

 void Handle_energy_saving(Light_System* sys)
{
  if (!sys) return;
}
// The main  machine operation

void Task_process_lighting_state(Light_System* sys)
{
    if (!sys) return;

    switch(sys->Sys_mode) 
    {
        case SYS_NORMAL:
            Handle_normal_mode(sys);
            break;
        case SYS_AUTO_PROFILE:
            Handle_auto_profile(sys);
            break;
        case SYS_ENERGY_SAVING:
            Handle_energy_saving(sys);
            break;
        default:
           
            set_system_mode(sys, SYS_NORMAL);
    }
}


//system Init
void Light_system_Init(Light_System* sys)
{
    if (!sys) return;   
     memset(sys, 0, sizeof(Light_System));  // 清零初始化
     sys->Sys_mode = SYS_NORMAL;
     sys->Light_state = LIGHT_OFF;
}

// Task start
void Task_Init()
{
    Light_Init();
    keystroke_Init();
    Extern_Interrupt_Init();
    Light_system_Init(&LightSystem);
 
}
//Task Mode check
void Task_Event_Mode_Check()
{
    if(interrupt_Flag!=True) return;
    switch(HAL_Light_Control_Structure.Hal_Mode_Change)
    {
        case Normal_State: set_system_mode(&LightSystem ,SYS_NORMAL);        interrupt_Flag = False; break;
        case ENERGY_State: set_system_mode(&LightSystem ,SYS_AUTO_PROFILE);  interrupt_Flag = False; break;
        case Auto_State: set_system_mode(&LightSystem , SYS_ENERGY_SAVING);   interrupt_Flag = False; break;
    }
}

//Task Run
void Task_Process_Begin()
{
    Task_process_lighting_state(&LightSystem);

}
#endif

/*
架构主要逻辑：
系统初始化->系统查询状态->系统运行状态
            三个运行状态模式
                            ->正常模式->轮训检测不同区域按钮状态->控制灯光
                            ->节能模式->轮询检测不同区域人员情况->控制灯光
                            ->情景模式->指定区域->检测环境光强度->pid控制->目标光强度
            1个触发状态机制->改变系统状态
            1个安全机制->轮询检测不同区域温度->到达指定温度关断电源并发出警报

    若增加上层接口，那再议
*/